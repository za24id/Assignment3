// RUN: %dragonegg -g -x c -S -o /dev/null - < %s

void dummy() {}
