// RUN: %dragonegg -S %s
// RUN: %dragonegg -S %s -m96bit-long-double
// RUN: %dragonegg -S %s -m128bit-long-double
long double d;
