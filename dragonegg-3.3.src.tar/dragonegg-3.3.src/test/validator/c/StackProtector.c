// RUN: %dragonegg -S %s -fstack-protector --param ssp-buffer-size=1
