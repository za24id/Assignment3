static int f0() { return 1; }
int f1() { return f0(); }
