/* Do not pass a typedef when creating debug info for the function definition */
typedef void fn_t();
fn_t b;
void b() {}
