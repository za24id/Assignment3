void X(void) {
  auto void D(void);
  void E(void) { D(); }
  void D(void) {}
  E();
}
