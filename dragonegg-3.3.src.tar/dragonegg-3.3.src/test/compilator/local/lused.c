void f(void) {
  __attribute__((used)) int local_var;
}
