int f(int x, int y, int b) {
  return 0;
  return b ? x : y;
}
